package com.escape.escape;

public class Obstacle extends GameObject
{
    public Obstacle(int x, int y)
    {
        super(x, y);
    }

}